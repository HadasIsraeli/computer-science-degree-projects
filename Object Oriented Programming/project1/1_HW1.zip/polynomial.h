#pragma once
#include <iostream>
using namespace std;

class Polynomial
{
	friend class Rational;
	friend ostream& operator<<(ostream&, const Polynomial&);

public:
	Polynomial(int = 0);
	Polynomial(double*,int);
	
	static int maxDegree;

	void setDegree(int);
	void setCoeff(int, double);
	static int getMaxDegree();
	const int getDegree(bool = true);
	Polynomial& operator=(const Polynomial&);
	~Polynomial();

private:
	int currDegree;
	double *arrDegree;
	int degree;

};


