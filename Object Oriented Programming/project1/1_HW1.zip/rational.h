#pragma once
#include <iostream>
#include "polynomial.h"
using namespace std;

class Rational
{
	friend ostream& operator<<(ostream&, Rational&);
public:
	Rational();
	Rational(Polynomial&, Polynomial&);
	void print();
	Polynomial& getNom();
	Polynomial& getDenom();

private:
	Polynomial Nom;
	Polynomial Denom;
};

