#include "rational.h"

using namespace std;

Rational::Rational()
{
	Nom.arrDegree[0] = 0;
	Denom.arrDegree[0] = 1;
}

Rational::Rational(Polynomial& nom, Polynomial& denom)
{
	Nom = nom;
	Denom = denom;
}

void Rational::print()
{
	cout << this->Nom;
	cout << "--------------------------" << endl;
	cout << this->Denom;
}

ostream& operator<<(ostream& out, Rational& rational)
{
	out << rational.Nom;
	out << "--------------------------" << endl;
	out << rational.Denom;
	return out;
}

Polynomial& Rational::getNom()
{
	return this->Nom;
}

Polynomial& Rational::getDenom()
{
	return this->Denom;
}

