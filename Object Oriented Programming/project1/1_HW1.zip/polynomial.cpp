#include "polynomial.h"

using namespace std;

Polynomial::Polynomial(int deg)
{
	int i;
	currDegree = deg;
	degree = deg;
	if (!deg)
	{
		arrDegree = new double();
	}
	else
	{
		arrDegree = new double[deg+1];
	}
	for (i = 0; i <= deg; i++)
	{
		arrDegree[i] = 0;
	}
}

Polynomial::~Polynomial()
{
	delete[] arrDegree;
}

int Polynomial::maxDegree = 0;

Polynomial::Polynomial(double* coeffArray,int size)
{
	int i;
	degree = size;
	currDegree = size;
	if (maxDegree < size)
	{
		maxDegree = size;
	}
	arrDegree = new double[size + 1];
	for (i = 0; i <= size; i++)
	{
		arrDegree[i] = coeffArray[i];
	}
}

void Polynomial::setDegree(int deg)
{
	degree = deg;
}

void Polynomial::setCoeff(int deg, double number)
{
	if (degree == deg)
	{
		arrDegree[deg] = number;
	}
	else
	{
		double *temp = new double[deg + 1];
		degree = deg;
		int i = 0;
		if (degree > deg)
		{
			for (i = 0; i < deg; i++)
			{
				temp[i] = arrDegree[i];
			}
		}
		else
		{
			for (i = 0; i < deg; i++)
			{
				if(i<=degree)
				{
					temp[i] = arrDegree[i];
				}
				else 
				{
					temp[i] = 0;
				}
			}
		}
		temp[deg] = number;
		delete[]arrDegree;
		arrDegree = temp;
	}
}

int Polynomial::getMaxDegree()
{
	return maxDegree;
}

const int Polynomial::getDegree(bool currentDegree)
{
	if (currentDegree==false)
	{
		return currDegree;
	}
	else 
	{
		return degree;
	}
}

ostream& operator<<(ostream& out, const Polynomial& poly)
{
	if (poly.degree > 0 && poly.arrDegree[poly.degree] != 0) {
		out << "polynomial = " << poly.arrDegree[0] << "+";
		for (int i = 1; i < poly.degree; i++)
			out << poly.arrDegree[i] << "X^" << i << "+";
		out << poly.arrDegree[poly.degree] << "X^" << poly.degree << endl;
	}
	else
		out << "polynomial = " << poly.arrDegree[0] << endl;

	return out;
}

Polynomial& Polynomial:: operator=(const Polynomial& other)
{
	if (this->degree != other.degree)
	{
		delete[] this->arrDegree;
		this->arrDegree = new double[other.degree + 1];
		for (int i = 0; i <= other.degree; i++)
			this->arrDegree[i] = other.arrDegree[i];
		this->degree = other.degree;
	}
	//else
	for (int i = 0; i <= other.degree; i++)
		this->arrDegree[i] = other.arrDegree[i];
	return *this;
}