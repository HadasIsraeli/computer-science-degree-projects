#pragma once
#include <math.h>
#include <iostream>

using namespace std;

class Figure2D 
{
	friend ostream &operator<<(ostream &o, Figure2D &d);

private:
	double x;
	double y;
	double length;
	double height;
	const char *name = NULL;//=NULL Needed for compiler of the testing engine

public:
	Figure2D(double l, double h, double x = 0, double y = 0);
	Figure2D(Figure2D &f);
	Figure2D();
	virtual ~Figure2D();
	const Figure2D &operator=(Figure2D &d);
	void setName(const char *);
	double getX() const;
	double getY() const;
	double getLength() const;
	double getHeight() const;
	const char* getName() const;
	virtual double Area() = 0;
	virtual double Perimeter() = 0;
	virtual void Shift(double dx, double dy) = 0;
	void MoveTo(double newX, double newY);
	virtual void Resize(double newL, double newH);
	virtual void Scale(double kx, double ky) = 0;
	virtual bool isInside(Figure2D* P) = 0;
	virtual void print() const = 0;

};