#pragma once
#include <iostream>
#include "Figure2D.h"
#include "Point.h"

using namespace std;

class Segment : public Figure2D
{
public:
	//Segment();
	Segment(const char*, Point, Point);

	~Segment();

	double Area();
	double Perimeter();
	void print() const;
	void Resize(double, double);
	void Shift(double, double);
	void Scale(double, double);
	bool isInside(Figure2D* P);

private:
	Point point1;
	Point point2;
	bool way;
};

