#include "Point.h"
#include <iostream>
using namespace std;

Point::Point():Figure2D(){}

Point::Point(const char* name, double x, double y):Figure2D(0, 0, x, y)
{
	this->setName(name);
}

Point::~Point(){}


double Point::Area()
{
	return 0;
}

double Point::Perimeter()
{
	return 0;
}

void Point::print() const
{
	cout << this->getName() << ": (" << this->getX() << ", " << this->getY() << ")" << endl;
}

void Point::Resize(double newLength, double newHeight){}

void Point::Shift(double x, double y)
{
	MoveTo((this->getX() + x), (this->getY() + y));
}

void Point::Scale(double x, double y)
{
	MoveTo((this->getX() * x), (this->getY() * y));
}

bool Point::isInside(Figure2D* P)
{
	if ((P->getX() == this->getX()) && (P->getY() == this->getY()))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}