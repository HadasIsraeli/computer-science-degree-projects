#pragma once
#include <iostream>
#include "Figure2D.h"
#include "Point.h"

using namespace std;

class Square : public Figure2D
{
	friend ostream& operator<<(ostream&, Square&);

public:
	Square();
	Square(const char*, Point, double);
	Square(const char*, Point, Point);

	~Square();

	double Area();
	double Perimeter();
	void print() const;
	void Resize(double, double);
	void Shift(double, double);
	void Scale(double, double);
	bool isInside(Figure2D* P);

private:
	double xCenter;
	double yCenter;
	Point point1;
	Point point2;
};

