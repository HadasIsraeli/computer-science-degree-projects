#pragma once
#include "Figure2D.h"
#include <iostream>

using namespace std;

class Point : public Figure2D
{
public:
	Point();
	Point(const char*, double, double);

	~Point();

	double Area();
	double Perimeter();
	void print() const;
	void Resize(double, double);
	void Shift(double, double);
	void Scale(double, double);
	bool isInside(Figure2D* P);
};

