#include "Rectangle.h"
#include <iostream>
using namespace std;

Rectangle::Rectangle(const char* name, Point pointP, Point pointQ):Figure2D(0, 0, pointP.getX(), pointQ.getY())
{
	point1 = pointP;
	point2 = pointQ;
	double smallX = pointP.getX();
	double smallY = pointP.getY();
	double tempLength = getX();
	double tempHeight = getY();
	if (smallX > pointQ.getX())
	{
		smallX = pointQ.getX();
		tempLength = pointP.getX() - smallX;
	}
	else if (smallX < pointQ.getX())
	{
		tempLength = pointQ.getX() - smallX;
	}
	if (smallY > pointQ.getY())
	{
		smallY = pointQ.getY();
		tempHeight = pointP.getY() - smallY;
	}
	else if (smallY < pointQ.getY())
	{
		tempHeight = pointQ.getY() - smallY;
	}
	MoveTo(smallX, smallY);
	Figure2D::Resize(abs(tempLength), abs(tempHeight));
	this->setName(name);
}

Rectangle::~Rectangle(){}

double Rectangle::Area() {
	return this->getHeight() * getLength();
}

double Rectangle::Perimeter() {
	return ((this->getLength() * 2) + (this->getHeight() * 2));
}

void Rectangle::print() const
{
	cout << this->getName() << ": " << "Point(" << this->getX() << ", " << this->getY();
	cout << ")-Point(" << this->getX() + this->getLength() << ", " << this->getY() + this->getHeight() << ")" << endl;
}

void Rectangle::Resize(double newLength, double newHeight)
{
	double AddToLength = newLength - this->getLength();
	double AddToHeight = newHeight - this->getHeight();
	Figure2D::Resize(newLength, newHeight);
	point2.MoveTo(point2.getX() + AddToLength, point2.getY() + AddToHeight);
}

void Rectangle::Shift(double x, double y)
{
	MoveTo((this->getX() + x), (this->getY() + y));
	point1.MoveTo((point1.getX() + x), (point1.getY() + y));
	point2.MoveTo((point2.getX() + x), (point2.getY() + y));
}

void Rectangle::Scale(double x, double y) 
{
	Resize((this->getLength() * x), (this->getHeight() * y));
	point1.MoveTo((point1.getX()), (point2.getY() + this->getHeight()));
	point2.MoveTo((point2.getX() - this->getLength()), (point2.getY()));
}

bool Rectangle::isInside(Figure2D* P)
{
	if (P->getX() >= this->getX())//15>=11
	{  
		if (P->getX() <= (this->getLength() + this->getX()))//15<= 6+11 
		{ 
			if (P->getY() >= this->getY())//10>=1
			{ 
				if (P->getY() <= this->getY() + this->getHeight())//10<=49 
				{ 
					return 1;
				}
			}
		}
	}
	return 0;
}
