#include "Segment.h"
#include <iostream>
using namespace std;

Segment::Segment(const char* name, Point pointP, Point pointQ):Figure2D(0, 0, pointP.getX(), pointQ.getY())
{
	point1 = pointP;
	point2 = pointQ;
	double smallX = pointP.getX();
	double smallY = pointP.getY();
	double tempLength = getX();
	double tempHeight = getY();
	if (smallX > pointQ.getX())
	{
		smallX = pointQ.getX();
		tempLength = pointP.getX() - smallX;
	}
	else if (smallX < pointQ.getX())
	{
		tempLength = pointQ.getX()- smallX;
	}
	if (smallY > pointQ.getY())
	{
		smallY = pointQ.getY();
		tempHeight = pointP.getY() - smallY;
	}
	else if (smallY < pointQ.getY())
	{
		tempHeight = pointQ.getY() - smallY;
	}
	MoveTo(smallX, smallY);
	Figure2D::Resize(abs(tempLength), abs(tempHeight));
	this->way = true;
	if (pointP.getX() > pointP.getX() && pointP.getY() > pointP.getY())
	{
		this->way = true;
	}
	else if (pointP.getX() < pointP.getX() && pointP.getY() < pointP.getY())
	{
		this->way = false;
	}
	this->setName(name);
}

Segment::~Segment(){}

double Segment::Area()
{
	return 0;
}

double Segment::Perimeter()
{
	return (sqrt(pow(this->getHeight(), 2) + (pow(this->getLength(), 2))));
}

void Segment::print() const
{
	cout << this->getName() << ": Point(" << point1.getX() << ", " << point1.getY();
	cout << ")-Point(" << point2.getX() << ", " << point2.getY() << ")" << endl;
}

void Segment::Resize(double newLLength, double newHeight)
{
	double AddToLength = newLLength - this->getLength();
	double AddToHeight = newHeight - this->getHeight();
	Figure2D::Resize(newLLength, newHeight);
	if (this->way == true) 
	{
		point1.MoveTo(point1.getX(), point1.getY() + AddToHeight);
		point2.MoveTo(point2.getX() + AddToLength, point2.getY());
	}
	if (this->way == false) 
	{
		point1.MoveTo((point1.getX() + AddToLength), (point1.getY() + AddToHeight));
	}
}

void Segment::Shift(double x, double y)
{
	MoveTo((this->getX() + x), (this->getY() + y));
	point1.MoveTo((point1.getX() + x), (point1.getY() + y));
	point2.MoveTo((point2.getX() + x), (point2.getY() + y));
}

void Segment::Scale(double x, double y)
{
	Resize((this->getLength() * x), (this->getHeight() * y));
}

bool Segment::isInside(Figure2D* P)
{
	if (P->getX() >= this->getX())//15>=11 
	{  
		if (P->getX() <= (this->getLength() + this->getX()))//15<= 6+11
		{ 
			if (P->getY() >= this->getY())//10>=1 
			{ 
				if (P->getY() <= this->getY() + this->getHeight())//10<=49 
				{ 
					return 1;
				}
			}
		}
	}
	return 0;
}