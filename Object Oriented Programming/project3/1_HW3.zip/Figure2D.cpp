#include "Figure2D.h"
#include <iostream>

using namespace std;

Figure2D::Figure2D()
{
	x = 0;
	y = 0;
	length = 0;
	height = 0;
	setName("");
}

Figure2D::Figure2D(Figure2D &f)
{
	this->x = f.getX();
	this->y = f.getY();
	this->length = f.getLength();
	this->height = f.getHeight();
	this->setName(f.getName());
}

Figure2D::Figure2D(double length, double height, double x, double y) {
	this->length = length;
	this->height = height;
	this->x = x;
	this->y = y;
	this->setName(name);
}

Figure2D::~Figure2D(){}

const Figure2D& Figure2D::operator=(Figure2D& d) {
	this->length = d.getLength();
	this->height = d.getHeight();
	this->x = d.getX();
	this->y = d.getY();
	this->setName(d.getName());
	return *this;
}

void Figure2D::setName(const char* name)
{
	this->name = name;
}

double Figure2D::getX() const
{
	return this->x;
}

double Figure2D::getY() const
{
	return this->y;
}

double Figure2D::getLength() const
{
	return this->length;
}

double Figure2D::getHeight() const
{
	return this->height;
}

const char* Figure2D::getName() const
{
	return name;
}

/*double Figure2D::Area(){}//?

double Figure2D::Perimeter(){}//?

void Figure2D::Shift(double dx, double dy){}//?
*/
void Figure2D::MoveTo(double newX, double newY)
{
	x = newX;
	y = newY;
}

void Figure2D::Resize(double newLength, double newHeight)
{
	length = newLength;
	height = newHeight;
}

/*void Figure2D::Scale(double kx, double ky){}//?=0

bool Figure2D::isInside(Figure2D *P){}//?

void Figure2D::print(){}//?
*/
ostream &operator<<(ostream &out, Figure2D &d)
{
	out << d.getName() << ": x=" << d.getX() << ", y=" << d.getY();
	out << ", length=" << d.getLength() << ", height=" << d.getHeight();
	return out;
}
