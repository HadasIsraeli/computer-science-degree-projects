#include "Square.h"
#include "Point.h"
#include <iostream>
using namespace std;

Square::Square() :Figure2D(){}

Square::Square(const char* name, Point pointP, double number) : Figure2D(number, number, pointP.getX() + number / 2, pointP.getY() + number / 2)
{
	this->setName(name);
}

Square::Square(const char* name, Point pointP, Point pointQ):Figure2D(0, 0, pointP.getX(), pointQ.getY())
{
	point1 = pointP;
	point2 = pointQ;
	double smallX = pointP.getX();
	double smallY = pointP.getY();
	double tempLength = getX();
	double tempHeight = getY();
	this->xCenter = ((pointP.getX() + pointQ.getX()) / 2);
	this->yCenter = ((pointP.getY() + pointQ.getY()) / 2);
	if (smallX > pointQ.getX())
	{
		smallX = pointQ.getX();
		tempLength = pointP.getX() - smallX;
	}
	else if (smallX < pointQ.getX())
	{
		tempLength = pointQ.getX() - smallX;
	}
	if (smallY > pointQ.getY())
	{
		smallY = pointQ.getY();
		tempHeight = pointP.getY() - smallY;
	}
	else if (smallY < pointQ.getY())
	{
		tempHeight = pointQ.getY() - smallY;
	}
	MoveTo(smallX, smallY);
	Figure2D::Resize(abs(tempLength), abs(tempHeight));
	this->setName(name);
}

Square::~Square(){}

double Square::Perimeter()
{
	return getLength() * 4;
}

double Square::Area()
{
	return getLength() * getLength();
}

void Square::print() const
{
	cout << "Square " << this->getName() << " with center (" << this->xCenter << ", " << this->yCenter;
	cout << ") and side = " << this->getLength() << endl;
}

void Square::Resize(double newLength, double newHeight)
{
	double AddToLength = newLength - this->getLength();
	double AddToHeight = newHeight - this->getHeight();
	Figure2D::Resize(newLength, newHeight);
	point2.MoveTo(point2.getX() + AddToLength, point2.getY() + AddToHeight);
	this->xCenter = ((point1.getX() + point2.getX()) / 2);
	this->yCenter = ((point1.getY() + point2.getY()) / 2);
}

void Square::Shift(double x, double y)
{
	MoveTo((this->getX() + x), (this->getY() + y));
	point1.MoveTo((point1.getX() + x), (point1.getY() + y));
	point2.MoveTo((point2.getX() + x), (point2.getY() + y));
	this->xCenter = ((point1.getX() + point2.getX()) / 2);
	this->yCenter = ((point1.getY() + point2.getY()) / 2);
}

void Square::Scale(double x, double y)
{
	Resize((this->getLength() * x), (this->getHeight() * y));
	point1.MoveTo((point1.getX()), (point2.getY() + this->getHeight()));
	point2.MoveTo((point2.getX() - this->getLength()), (point2.getY()));
}

bool Square::isInside(Figure2D* P)
{
	if (this->getY() + this->getHeight() / this->getY() <= P->getY()) 
	{
		if (P->getY() <= this->getY() + getHeight() / getY() * 2) 
		{
			if (this->getX() <= P->getX()) 
			{
				if (P->getX() <= this->getY() + this->getLength()) 
				{
					return 1;
				}
			}
		}
	}
	return 0;
}

ostream& operator<<(ostream& o, Square& point)
{
	cout << "Square " << point.getName() << " with center (" << point.getX() << ", " << point.getY();
	cout << ") and side = " << point.getLength() << endl;
	return o;
}
