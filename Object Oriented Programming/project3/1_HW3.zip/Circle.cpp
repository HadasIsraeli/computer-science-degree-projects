#include "Circle.h"
#include <iostream>

#define PAI 3.1415926535897931

using namespace std;

Circle::Circle(const char* name, Point pointP, double number):Figure2D(number*2,number*2,pointP.getX(),pointP.getY())
{
	this->setName(name);
	xCenter = pointP.getX() + number;
	yCenter = pointP.getY() + number;
}

Circle::~Circle(){}

double Circle::Area()
{
	return (PAI*(this->getLength() / 2 * this->getLength() / 2));
}

double Circle::Perimeter()
{
	return 2 * PAI*this->getLength() / 2;
}

void Circle::print() const
{
	cout << "Circle " << this->getName() << " with center (" << this->xCenter << ", " << this->yCenter;
	cout << ") and radius = " << this->getLength() / 2 << endl;
}

void Circle::Resize(double newLength, double newHeight)
{
Figure2D::Resize(newLength, newHeight);
this->xCenter = (this->getX() + this->getLength() / 2);
this->yCenter = (this->getY() + this->getHeight() / 2);
}

void Circle::Shift(double x, double y) 
{
	MoveTo((this->getX() + x), (this->getY() + y));
	this->xCenter = (this->getX() + this->getLength() / 2);
	this->yCenter = (this->getY() + this->getHeight() / 2);
}


void Circle::Scale(double x, double y) 
{
	Resize((this->getLength() * x), (this->getHeight() * y));
}

bool Circle::isInside(Figure2D* P)
{
	if (sqrt(pow(P->getX() - this->xCenter, 2) + pow(P->getY() - this->yCenter, 2))< this->getLength() / 2) 
	{
		return 1;
	}
	return 0;
}
