/*
Assigned by:
Hadas Israeli 207041443
Inbar Israeli 205925290
*/
#pragma once
#include <iostream>
#include "polynomial.h"
using namespace std;

class rational
{
	friend ostream& operator<<(ostream&, rational&);

public:
	rational();
	rational(Polynomial&, Polynomial&);
	rational(const rational&);

	rational operator*(const rational);
	rational operator+(const rational);

	void print() const;

	Polynomial& getNom();
	Polynomial& getDenom();

private:
	Polynomial Nom;
	Polynomial Denom;
};



