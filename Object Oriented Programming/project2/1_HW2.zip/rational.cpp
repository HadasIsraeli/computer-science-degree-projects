/*
Assigned by:
Hadas Israeli 207041443
Inbar Israeli 205925290
*/
#include "rational.h"
#include <iostream>

using namespace std;

rational::rational()
{
	Nom.arrDegree[0] = 0;
	Denom.arrDegree[0] = 1;
}

rational::rational(Polynomial& nom, Polynomial& denom)
{
	Nom = nom;
	Denom = denom;
}

rational::rational(const rational& ra)
{
	this->Nom = ra.Nom;
	this->Denom = ra.Denom;
}

void rational::print() const 
{
	cout << this->Nom;
	cout << "--------------------------" << endl;
	cout << this->Denom;
}

ostream& operator<<(ostream& out, rational& rational1)
{
	out << rational1.Nom;
	out << "--------------------------" << endl;
	out << rational1.Denom;
	return out;
}

Polynomial& rational::getNom()
{
	return this->Nom;
}

Polynomial& rational::getDenom()
{
	return this->Denom;
}

rational rational::operator*(const rational rational1)
{
	rational temp(*this);
	temp.Nom = temp.Nom * rational1.Nom;
	temp.Denom = temp.Denom * rational1.Denom;
	if (temp.Nom.degree > Polynomial::maxDegree)
	{
		Polynomial::maxDegree = temp.Nom.degree;
	}
	if (temp.Denom.degree > Polynomial::maxDegree)
	{
		Polynomial::maxDegree = temp.Denom.degree;
	}
	return temp;
}

rational rational::operator+(const rational rational1)
{
	rational temp(*this);
	temp.Denom = temp.Denom * rational1.Denom;
	temp.Nom = (temp.Nom * rational1.Denom) + (this->Denom * rational1.Nom);
	if (temp.Nom.degree > Polynomial::maxDegree)
	{
		Polynomial::maxDegree = temp.Nom.degree;
	}
	if (temp.Denom.degree > Polynomial::maxDegree)
	{
		Polynomial::maxDegree = temp.Denom.degree;
	}
	return temp;
}
