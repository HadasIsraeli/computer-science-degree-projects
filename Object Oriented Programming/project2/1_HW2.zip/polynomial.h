/*
Assigned by:
Hadas Israeli 207041443
Inbar Israeli 205925290
*/
#pragma once
#include <iostream>
using namespace std;

class Polynomial
{
	friend class rational;
	friend ostream& operator<<(ostream&, const Polynomial&);
	friend Polynomial operator*(double, Polynomial&);

public:
	Polynomial(int = 0);
	Polynomial(double*, int);
	Polynomial(const Polynomial&);

	static int maxDegree;
	static int getMaxDegree();

	void setDegree(int);
	void setCoeff(int, double);
	const int getDegree(bool = true);
	double& getArr(int);

	Polynomial& operator=(const Polynomial&);
	double& operator[](const int);
	//const double& operator[](const int);
	Polynomial operator+(const Polynomial);
	Polynomial operator*(const Polynomial);
	Polynomial& operator-(const Polynomial&);
	
	~Polynomial();

private:
	int currDegree;
	double *arrDegree;
	int degree;

};



