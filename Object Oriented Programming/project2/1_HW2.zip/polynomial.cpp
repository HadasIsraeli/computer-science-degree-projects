/*
Assigned by:
Hadas Israeli 207041443
Inbar Israeli 205925290
*/
#include "polynomial.h"

using namespace std;

int Polynomial::maxDegree = 0;

Polynomial::Polynomial(int deg)
{
	int i=0;
	currDegree = deg;
	degree = deg;
	if (!deg)
	{
		arrDegree = new double();
	}
	else
	{
		arrDegree = new double[deg + 1];
	}
	for (i = 0; i <= deg; i++)
	{
		arrDegree[i] = 0;
	}
}

Polynomial::Polynomial(double* coeffArray, int size)
{
	int i = 0, newSize = 0;
	for (int i = size; i > 0; i--) 
	{
		if (coeffArray[i] != 0)
		{
			newSize = i;
			break;
		}
	}
	degree = newSize;
	currDegree = newSize;
	if (maxDegree < newSize)
	{
		maxDegree = newSize;
	}
	arrDegree = new double[newSize + 1];
	for (i = 0; i <= newSize; i++)
	{
		arrDegree[i] = coeffArray[i];
	}
}

Polynomial::Polynomial(const Polynomial& poly1)
{
	int i=0;
	degree = poly1.degree;
	if (maxDegree < poly1.degree)
	{
		maxDegree = poly1.degree;
	}
	arrDegree = new double[degree + 1];
	for (i = 0; i <= degree; i++)
	{
		arrDegree[i] = poly1.arrDegree[i];
	}
}

Polynomial::~Polynomial()
{
	delete[] arrDegree;
}

void Polynomial::setDegree(int deg)
{
	degree = deg;
}

void Polynomial::setCoeff(int deg, double number)
{
	if (degree == deg)
	{
		arrDegree[deg] = number;
	}
	else
	{
		double *temp = new double[deg + 1];
		degree = deg;
		int i = 0;
		if (degree > deg)
		{
			for (i = 0; i < deg; i++)
			{
				temp[i] = arrDegree[i];
			}
		}
		else
		{
			for (i = 0; i < deg; i++)
			{
				if (i <= degree)
				{
					temp[i] = arrDegree[i];
				}
				else
				{
					temp[i] = 0;
				}
			}
		}
		temp[deg] = number;
		delete[]arrDegree;
		arrDegree = temp;
	}
}

int Polynomial::getMaxDegree()
{
	return maxDegree;
}

const int Polynomial::getDegree(bool currentDegree)
{
	if (currentDegree == false)
	{
		return currDegree;
	}
	else
	{
		return degree;
	}
}

double& Polynomial::getArr(int size) 
{
	return this->arrDegree[size];
}

ostream& operator<<(ostream& out, const Polynomial& poly)
{
	int i = 0;
	if (poly.degree > 0 && poly.arrDegree[poly.degree] != 0)
	{
		out << "polynomial = " << poly.arrDegree[0] << "+";
		for (i = 1; i < poly.degree; i++)
		{
			out << "("<< poly.arrDegree[i] <<")"<< "*X^" << i << "+";
		}
		out << "(" << poly.arrDegree[poly.degree] << ")" << "*X^" << poly.degree << endl;
	}
	else
	{
		out << "polynomial = " << poly.arrDegree[0] << endl;
	}
	return out;
}

Polynomial& Polynomial:: operator=(const Polynomial& other)
{
	int i=0;
	if (degree != other.degree)
	{
		delete[] arrDegree;
		arrDegree = new double[other.degree + 1];
		for (i = 0; i <= other.degree; i++)
		{
			arrDegree[i] = other.arrDegree[i];
		}
		this->degree = other.degree;
	}
	else 
	{
		for (i = 0; i <= other.degree; i++)
		{
			arrDegree[i] = other.arrDegree[i];
		}
	}
	return *this;
}

double& Polynomial::operator[](const int index)
{
	return this->arrDegree[index];
}

/*const double& Polynomial::operator[](const int index1)
{
	return arrDegree[index1];
}*/

Polynomial Polynomial::operator+(const Polynomial poly1)
{
	int i=0;
	if (degree >= poly1.degree)
	{
		for (i = 0; i <= poly1.degree; i++)
		{
			arrDegree[i] = arrDegree[i] + poly1.arrDegree[i];
		}
	}
	else
	{
		Polynomial temp(*this);
		degree = poly1.degree;
		arrDegree = new double[poly1.degree + 1];
		for (i = 0; i <= temp.degree; i++)
		{
			arrDegree[i] = temp.arrDegree[i] + poly1.arrDegree[i];
		}
		for (i = temp.degree + 1; i <= poly1.degree; i++)
		{
			arrDegree[i] = poly1.arrDegree[i];
		}
	}
	return *this;
}

Polynomial operator*(double num, Polynomial& poly)
{
	int i=0;
	Polynomial temp(poly);
	for (i = 0; i <= poly.degree; i++)
	{
		temp.arrDegree[i] *= num;
	}
	return temp;
}

Polynomial Polynomial::operator*(const Polynomial poly1)
{
	int maxDeg = degree + poly1.degree + 1;
	int i=0, j=0;
	Polynomial temp(maxDeg - 1);
	for (i = 0; i <= poly1.degree; i++)
	{
		for (j = 0; j <= degree; j++)
		{
			temp.arrDegree[i + j] = temp.arrDegree[i + j] + poly1.arrDegree[i] * this->arrDegree[j];
		}
	}
	delete[] arrDegree;
	arrDegree = new double[maxDeg];
	degree = (maxDeg - 1);
	for (i = 0; i < maxDeg; i++)
	{
		arrDegree[i] = temp.arrDegree[i];
	}
	return *this;
}

Polynomial& Polynomial:: operator-(const Polynomial& poly1)
{
	int i=0;
	if (degree >= poly1.degree)
	{
		for (i = 0; i <= poly1.degree; i++)
		{
			arrDegree[i] = arrDegree[i] - poly1.arrDegree[i];
		}
	}
	else
	{
		Polynomial temp(*this);
		degree = poly1.degree;
		delete[] arrDegree;
		arrDegree = new double[poly1.degree + 1];
		for (int i = 0; i <= temp.degree; i++)
		{
			arrDegree[i] = temp.arrDegree[i] - poly1.arrDegree[i];
		}
		for (i = 0; i <= poly1.degree; i++)
		{
			arrDegree[i] = -poly1.arrDegree[i];
		}
	}
	return *this;
}
